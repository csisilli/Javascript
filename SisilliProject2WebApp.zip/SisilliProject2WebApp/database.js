require('dotenv').config()
const Database = require('dbcmps369')

class ContactDB{
    constructor(){
        this.db = new Database();
    }

    async initialize() {
        await this.db.connect()

        await this.db.schema('Contact', [
            {name: 'ID', type: 'INTEGER'},
            {name: 'First Name', type: 'TEXT'},
            {name: 'Last Name', type: 'TEXT'},
            {name: 'Phone Number', type: 'TEXT'},
            {name: 'Email Address', type: 'TEXT'},
            {name: 'Street', type: 'TEXT'},
            {name: 'City', type: 'TEXT'},
            {name: 'State', type: 'TEXT'},
            {name: 'Zip Code', type: 'TEXT'},
            {name: 'Country', type: 'TEXT'},
            {name: 'Contact By Email', type: 'BOOLEAN'},
            {name: 'Contact By Phone', type: 'BOOLEAN'},
        ], 'ID');

        await this.db.schema('Users', [
            {name: 'ID', type: 'INTEGER'},
            {name: 'First Name', type: 'TEXT'},
            {name: 'Last Name', type: 'TEXT'},
            {name: 'Username', type: 'TEXT'},
            {name: 'Password', type: 'bcrypt'},
        ], 'ID');
    }


}

module.exports = ContactDB;