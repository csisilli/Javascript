const express= require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
//login page
router.get('/logout',async (req, res) => {
    req.session.user = undefined;
    res.redirect('/');
});
router.get('/login',async (req, res) => {
    res.render('login',{hide_login: true });
});
router.post('/login',async (req, res) => {
    const username = req.body.username.trim();
    const password = req.body.password.trim();
    const user = await req.db.findUserbyUsername(username);
    if(!user){
        res.render('login',{hide_login: true, message: 'Could not authenticate' });
        return;
    }
    if(user && bcrypt.compareSync(password, user.password)){
        req.session.user = user;
        res.redirect('/');
        
        return;
    }else{
        res.render('login',{hide_login: true, message: 'Could not authenticate' });
        return;
    }
});
//signup page
router.get('/signup',async (req, res) => {
    res.render('signup',{hide_login: true });
});
router.post('/signup',async (req, res) => {
    const username = req.body.username.trim();
    const password = req.body.password.trim();
    const confirmpassword = req.body.confirmpassword.trim();
    if(password != confirmpassword){
        res.render('signup',{hide_login: true, message: "Error: Passwords do not match" });
        return;
    }
    const user =await req.db.findUserbyUsername(username);
    if(user){
        res.render('signup',{hide_login: true, message: "Error: Username Exists" });
        return;
    }

    const salt =bcrypt.genSaltSync(10);
    const hash =bcrypt.hashSync(password, salt);
 
    const id =await req.db.createUser(username, hash);
    req.session.user = await req.db.findUserbyId(id);
    res.redirect('/');
    
});
module.exports =router;