const express= require('express');
const Database = require('./database');
const db= new Database('list.db');
db.initialize();
const app = express();
app.use(express.urlencoded({extended: true}));
//request to the database
app.use((req,res,next) => {
    console.log("Database send to request it");
    req.db=db;
    next();
})

app.set('view engine', 'pug');
app.locals.pretty = true;

//shorten the code instead of using app.get
app.use('/' ,require('./route/homePage'));
app.use('/login', require('./route/loginPage'));
app.use('/signup', require('./route/signPage'));
app.use('/create', require('./route/createPage'));

//runs the server
app.listen(3000, () => {
    console.log("Server Running")
});