const express = require('express')
const router = express.Router();
const moment = require('moment');

router.get('/', async (req, res) => {
    const lists = await req.db.findLists();
    lists.forEach(g => g.time = moment(parseInt(g.time)).format('MMM D yyyy - h:mma'))
    res.render('list', { lists: lists });
})

router.get('/:lists', async (req, res) => {
    const list = await req.db.findList(req.params.lists);
    list.forEach(g => g.time = moment(parseInt(g.time)).format('MMM D yyyy - h:mma'))
    res.render('list', { list: list });
});

module.exports = router;