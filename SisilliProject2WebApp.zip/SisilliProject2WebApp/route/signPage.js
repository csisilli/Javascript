const express = require('express')
const router = express.Router();
const bcrypt = require('bcrypt');


router.get('/logout', async (req, res) => {
    req.session.user = undefined;
    res.redirect('/');
})

router.get('/', (req, res) => {
    res.render('signup', { title: 'Sign Up', show_login: false });
})

router.post('/signup', async (req, res) => {
    const firstname =  req.body.first.trim();
    const lastname = req.body.last.trim();
    const username = req.body.username.trim();
    const password = req.body.signuppassword.trim();
    const confirmpassword = req.body.confirmpassword.trim();

    if(password != confirmpassword){
        res.render('signup', {show_login: false, message: "Error: Passwords Do Not Match"});
        return;
    }

    const user = await req.db.findUserByUserName(username);
    if (user) {

        res.render('signup', { show_login: true, message: 'Error: Account Exist' });
        return;
    }
    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(password, salt);
});

module.exports = router;