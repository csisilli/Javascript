const express= require('express');
const routers = express.Router();

routers.get('/', async (req,res) =>{
    res.render('homepage', {title: 'Home Page', show_login: true});
})

module.exports = routers;