const express = require('express')
const router = express.Router();

router.get('/', async (req, res) => {
    res.render('login', { title: 'Login', show_login: false });
});

router.post('/login', (req, res) => {
    const { username, password } = req.body;
    //throw error if username not correct or found
    req.db.get(`SELECT password FROM Users WHERE username = ?`, [username], (err, rep) => {
        if (err) {
            console.log(err);
            res.send('Error: Please Try Again!');
        } else if (!rep) {
            res.send('User does not exist');
        } else {
            const hash = rep.password;
            //If it correct it send a sucessful login in. Else it throws an error if  error occurs, wrong password. 
            bcrypt.compare(password, hash, (err, result) => {
                if (result) {
                    res.send('Login Sucessful!');
                } else if (!result) {
                    res.send('Error: Incorrect password');
                } else {
                    console.log(err);
                    res.send('Error: Please Try Again!');
                }
            });
        }
    });
});

module.exports = router;