const express = require('express')
const router = express.Router();



router.get('/', (req, res) => {
    res.render('create', { title: 'Create new contact', show_login: true });
});

router.post('/', async (req, res) => {
    const firstname =  req.body.firstname.trim();
    const lastname = req.body.lastname.trim();
    const phone = req.body.phonenumber.trim();
    const emailad = req.body.email.trim();
    const streets = req.body.street.trim();
    const city = req.body.city.trim();
    const zips = req.body.zip.trim();
    const countrys = req.body.country.trim();

    const contact = await req.db.findContact(firstname, lastname, emailad, phone);
    if (contact) {

        res.render('create', { show_login: true, message: 'Error: Contact Exist' });
        return;
    }

    const newcontact = await req.db.createContact(firstname, lastname, phone, emailad, streets, city, zips, countrys);
    res.redirect('/');

});

module.exports = router;